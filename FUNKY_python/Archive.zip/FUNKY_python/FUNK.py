"""Mac OS X"""
"""#1"""
def stink(person="", stink_type=""):
    print(""+person+" stinks like "+stink_type+".")

"""#2"""
def twinprint(text=""):
    print(text *2)

"""#3"""
def plus():
    while 10==10:
        num1 = input()
        num2 = input()
        float(num1)
        float(num2)
        ans = num1 + num2
        print(ans)
    
"""#4"""
def subtract():
    while 10==10:
        num1 = input()
        num2 = input()
        float(num1)
        float(num2)
        ans = num1 - num2
        print(ans)

"""#5"""
def divide():
    while 10==10:
        num1 = input()
        num2 = input()
        float(num1)
        float(num2)
        ans = num1 / num2
        print(ans)

"""#6"""
def multiply():
    while 10==10:
        num1 = input()
        num2 = input()
        float(num1)
        float(num2)
        ans = num1 * num2
        print(ans)

"""future updates will be made"""
"""v1.0"""
